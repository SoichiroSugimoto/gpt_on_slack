import os
import json
import boto3
from urllib import parse

import slack_functions as slack

from pynamodb.models import Model
from pynamodb.attributes import UnicodeAttribute, NumberAttribute, MapAttribute

dynamodb = boto3.resource('dynamodb')
conversations = dynamodb.Table('Conversation')

def lambda_handler(event, context):
  guide_message = conversations.get_item(
            Key={"message_id": 'm1'}
        )['Item']['message']
  receive_body = parse.parse_qs(event['body'])
  receive_payload = json.loads(receive_body["payload"][0])
  if (receive_payload['type'] == 'shortcut' and receive_payload['callback_id'] == 'shortcut_0000'):
    slack.post_channel_by_params(channel, guide_message)
  return (guide_message)
